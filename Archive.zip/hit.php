<!-- 900-choingay ; 904-taiios ; 909-taiapk -->
<meta http-equiv="Cache-Control" content="no-cache">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta http-equiv="Expires" content="-1">
<meta name="keywords" content="">
<meta name="description" content="go88 new">
<meta id='viewport' name='viewport' content='width=device-width, initial-scale=1' />
<script
    type='text/javascript'>window.ladi_viewport = function () { var screen_width = window.ladi_screen_width || window.screen.width; var width = window.innerWidth > 0 ? window.innerWidth : screen_width; var widthDevice = width; var is_desktop = width >= 768; var content = ""; if (typeof window.ladi_is_desktop == "undefined" || window.ladi_is_desktop == undefined) { window.ladi_is_desktop = is_desktop; } if (!is_desktop) { widthDevice = 420; } else { widthDevice = 960; } content = "width=" + widthDevice + ", user-scalable=no"; var scale = 1; if (!is_desktop && widthDevice != screen_width && screen_width > 0) { scale = screen_width / widthDevice; } if (scale != 1) { content += ", initial-scale=" + scale + ", minimum-scale=" + scale + ", maximum-scale=" + scale; } var docViewport = document.getElementById("viewport"); if (!docViewport) { docViewport = document.createElement("meta"); docViewport.setAttribute("id", "viewport"); docViewport.setAttribute("name", "viewport"); document.head.appendChild(docViewport); } docViewport.setAttribute("content", content); }; window.ladi_viewport(); window.ladi_fbq_data = []; window.ladi_fbq = function () { window.ladi_fbq_data.push(arguments); }; window.ladi_ttq_data = []; window.ladi_ttq = function () { window.ladi_ttq_data.push(arguments); };</script>
<link rel="canonical" href="https://preview.ladipage.me/64914a7b4a37000012f83c31" />
<meta property="og:url" content="http://preview.ladipage.me/64914a7b4a37000012f83c31" />
<meta property="og:title" content="Đặt tiêu đề trang" />
<meta property="og:type" content="website" />
<meta property="og:image"
    content="https://static.ladipage.net/63ea36ac81c3610012d6c96c/unnamed-20230326181331-rfbof.png">
<meta property="og:description" content="go88 new" />
<meta name="format-detection" content="telephone=no" />
<link rel="shortcut icon"
    href="https://static.ladipage.net/63ea36ac81c3610012d6c96c/unnamed-20230326181331-rfbof.png" />
<link rel="dns-prefetch">
<link rel="preconnect" href="https://fonts.googleapis.com/" crossorigin>
<link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
<link rel="preconnect" href="https://w.ladicdn.com/" crossorigin>
<link rel="preconnect" href="https://s.ladicdn.com/" crossorigin>
<link rel="preconnect" href="https://api.ldpform.com/" crossorigin>
<link rel="preconnect" href="https://a.ladipage.com/" crossorigin>
<link rel="preconnect" href="https://api.sales.ldpform.net/" crossorigin>
<link rel="preload" href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" as="style"
    onload="this.onload = null; this.rel = 'stylesheet';">
<link rel="preload" href="https://w.ladicdn.com/v2/source/ladipagev3.min.js?v=1691642835202" as="script">
<style id="style_ladi" type="text/css">
    a,
    abbr,
    acronym,
    address,
    applet,
    article,
    aside,
    audio,
    b,
    big,
    blockquote,
    body,
    button,
    canvas,
    caption,
    center,
    cite,
    code,
    dd,
    del,
    details,
    dfn,
    div,
    dl,
    dt,
    em,
    embed,
    fieldset,
    figcaption,
    figure,
    footer,
    form,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    header,
    hgroup,
    html,
    i,
    iframe,
    img,
    input,
    ins,
    kbd,
    label,
    legend,
    li,
    mark,
    menu,
    nav,
    object,
    ol,
    output,
    p,
    pre,
    q,
    ruby,
    s,
    samp,
    section,
    select,
    small,
    span,
    strike,
    strong,
    sub,
    summary,
    sup,
    table,
    tbody,
    td,
    textarea,
    tfoot,
    th,
    thead,
    time,
    tr,
    tt,
    u,
    ul,
    var,
    video {
        margin: 0;
        padding: 0;
        border: 0;
        outline: 0;
        font-size: 100%;
        font: inherit;
        vertical-align: baseline;
        box-sizing: border-box;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale
    }

    article,
    aside,
    details,
    figcaption,
    figure,
    footer,
    header,
    hgroup,
    menu,
    nav,
    section {
        display: block
    }

    body {
        line-height: 1
    }

    a {
        text-decoration: none
    }

    ol,
    ul {
        list-style: none
    }

    blockquote,
    q {
        quotes: none
    }

    blockquote:after,
    blockquote:before,
    q:after,
    q:before {
        content: '';
        content: none
    }

    table {
        border-collapse: collapse;
        border-spacing: 0
    }

    .ladi-loading {
        z-index: 900000000000;
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        background-color: rgba(0, 0, 0, .1)
    }

    .ladi-loading .loading {
        width: 80px;
        height: 80px;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        margin: auto;
        overflow: hidden;
        position: absolute
    }

    .ladi-loading .loading div {
        position: absolute;
        width: 6px;
        height: 6px;
        background: #fff;
        border-radius: 50%;
        animation: ladi-loading 1.2s linear infinite
    }

    .ladi-loading .loading div:nth-child(1) {
        animation-delay: 0s;
        top: 37px;
        left: 66px
    }

    .ladi-loading .loading div:nth-child(2) {
        animation-delay: -.1s;
        top: 22px;
        left: 62px
    }

    .ladi-loading .loading div:nth-child(3) {
        animation-delay: -.2s;
        top: 11px;
        left: 52px
    }

    .ladi-loading .loading div:nth-child(4) {
        animation-delay: -.3s;
        top: 7px;
        left: 37px
    }

    .ladi-loading .loading div:nth-child(5) {
        animation-delay: -.4s;
        top: 11px;
        left: 22px
    }

    .ladi-loading .loading div:nth-child(6) {
        animation-delay: -.5s;
        top: 22px;
        left: 11px
    }

    .ladi-loading .loading div:nth-child(7) {
        animation-delay: -.6s;
        top: 37px;
        left: 7px
    }

    .ladi-loading .loading div:nth-child(8) {
        animation-delay: -.7s;
        top: 52px;
        left: 11px
    }

    .ladi-loading .loading div:nth-child(9) {
        animation-delay: -.8s;
        top: 62px;
        left: 22px
    }

    .ladi-loading .loading div:nth-child(10) {
        animation-delay: -.9s;
        top: 66px;
        left: 37px
    }

    .ladi-loading .loading div:nth-child(11) {
        animation-delay: -1s;
        top: 62px;
        left: 52px
    }

    .ladi-loading .loading div:nth-child(12) {
        animation-delay: -1.1s;
        top: 52px;
        left: 62px
    }

    @keyframes ladi-loading {

        0%,
        100%,
        20%,
        80% {
            transform: scale(1)
        }

        50% {
            transform: scale(1.5)
        }
    }

    .ladipage-message {
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        z-index: 10000000000;
        background: rgba(0, 0, 0, .3)
    }

    .ladipage-message .ladipage-message-box {
        width: 400px;
        max-width: calc(100% - 50px);
        height: 160px;
        border: 1px solid rgba(0, 0, 0, .3);
        background-color: #fff;
        position: fixed;
        top: calc(50% - 155px);
        left: 0;
        right: 0;
        margin: auto;
        border-radius: 10px
    }

    .ladipage-message .ladipage-message-box span {
        display: block;
        background-color: rgba(6, 21, 40, .05);
        color: #000;
        padding: 12px 15px;
        font-weight: 600;
        font-size: 16px;
        line-height: 16px;
        border-top-left-radius: 10px;
        border-top-right-radius: 10px
    }

    .ladipage-message .ladipage-message-box .ladipage-message-text {
        display: -webkit-box;
        font-size: 14px;
        padding: 0 20px;
        margin-top: 10px;
        line-height: 18px;
        -webkit-line-clamp: 3;
        -webkit-box-orient: vertical;
        overflow: hidden;
        text-overflow: ellipsis
    }

    .ladipage-message .ladipage-message-box .ladipage-message-close {
        display: block;
        position: absolute;
        right: 15px;
        bottom: 10px;
        margin: 0 auto;
        padding: 10px 0;
        border: none;
        width: 80px;
        text-transform: uppercase;
        text-align: center;
        color: #000;
        background-color: #e6e6e6;
        border-radius: 5px;
        text-decoration: none;
        font-size: 14px;
        line-height: 14px;
        font-weight: 600;
        cursor: pointer
    }

    .lightbox-screen {
        display: none;
        position: fixed;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        bottom: 0;
        right: 0;
        margin: auto;
        z-index: 9000000080;
        background: rgba(0, 0, 0, .5)
    }

    .lightbox-screen .lightbox-close {
        position: absolute;
        z-index: 9000000090;
        cursor: pointer
    }

    .lightbox-screen .lightbox-hidden {
        display: none
    }

    .lightbox-screen .lightbox-close {
        width: 16px;
        height: 16px;
        margin: 10px;
        background-repeat: no-repeat;
        background-position: center center;
        background-image: url("data:image/svg+xml;utf8, %3Csvg%20width%3D%2224%22%20height%3D%2224%22%20viewBox%3D%220%200%2024%2024%22%20xmlns%3D%22http%3A%2F%2Fwww.w3.org%2F2000%2Fsvg%22%20fill%3D%22%23fff%22%3E%3Cpath%20fill-rule%3D%22evenodd%22%20clip-rule%3D%22evenodd%22%20d%3D%22M23.4144%202.00015L2.00015%2023.4144L0.585938%2022.0002L22.0002%200.585938L23.4144%202.00015Z%22%3E%3C%2Fpath%3E%3Cpath%20fill-rule%3D%22evenodd%22%20clip-rule%3D%22evenodd%22%20d%3D%22M2.00015%200.585938L23.4144%2022.0002L22.0002%2023.4144L0.585938%202.00015L2.00015%200.585938Z%22%3E%3C%2Fpath%3E%3C%2Fsvg%3E")
    }

    body {
        font-size: 12px;
        -ms-text-size-adjust: none;
        -moz-text-size-adjust: none;
        -o-text-size-adjust: none;
        -webkit-text-size-adjust: none;
        background-color: #fff;
    }

    .overflow-hidden {
        overflow: hidden;
    }

    .ladi-transition {
        transition: all 150ms linear 0s;
    }

    .opacity-0 {
        opacity: 0;
    }

    .height-0 {
        height: 0 !important;
    }

    .pointer-events-none {
        pointer-events: none;
    }

    .transition-parent-collapse-height {
        transition: height 150ms linear 0s;
    }

    .transition-parent-collapse-top {
        transition: top 150ms linear 0s;
    }

    .transition-readmore {
        transition: height 350ms linear 0s;
    }

    .transition-collapse {
        transition: height 150ms linear 0s;
    }

    body.grab {
        cursor: grab;
    }

    .ladi-wraper {
        width: 100%;
        min-height: 100%;
        overflow: hidden;
    }

    .ladi-container {
        position: relative;
        margin: 0 auto;
        height: 100%;
    }

    .ladi-element {
        position: absolute;
    }

    .ladi-overlay {
        position: absolute;
        top: 0;
        left: 0;
        height: 100%;
        width: 100%;
        pointer-events: none;
    }

    @media (hover: hover) {
        .ladi-check-hover {
            opacity: 0;
        }
    }

    .ladi-section {
        margin: 0 auto;
        position: relative;
    }

    .ladi-section[data-tab-id] {
        display: none;
    }

    .ladi-section.selected[data-tab-id] {
        display: block;
    }

    .ladi-section .ladi-section-background {
        position: absolute;
        width: 100%;
        height: 100%;
        top: 0;
        left: 0;
        pointer-events: none;
        overflow: hidden;
    }

    .ladi-image {
        position: absolute;
        width: 100%;
        height: 100%;
        overflow: hidden;
    }

    .ladi-image .ladi-image-background {
        background-repeat: no-repeat;
        background-position: left top;
        background-size: cover;
        background-attachment: scroll;
        background-origin: content-box;
        position: absolute;
        margin: 0 auto;
        width: 100%;
        height: 100%;
        pointer-events: none;
    }

    a[data-action] {
        user-select: none;
        -webkit-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        cursor: pointer
    }

    a:visited {
        color: inherit
    }

    a:link {
        color: inherit
    }

    [data-opacity="0"] {
        opacity: 0
    }

    [data-hidden="true"] {
        display: none
    }

    [data-action="true"] {
        cursor: pointer
    }

    .ladi-hidden {
        display: none
    }

    .ladi-animation-hidden {
        visibility: hidden !important;
        opacity: 0 !important
    }

    .element-click-selected {
        cursor: pointer
    }

    .is-2nd-click {
        cursor: pointer
    }

    .ladi-button-shape.is-2nd-click,
    .ladi-accordion-shape.is-2nd-click {
        z-index: 1
    }

    .backdrop-popup {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 90000060
    }

    .backdrop-dropbox {
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 90000040
    }

    .ladi-lazyload {
        background-image: none !important;
    }

    .ladi-list-paragraph ul li.ladi-lazyload:before {
        background-image: none !important;
    }

    @media (min-width: 768px) {
        .ladi-fullwidth {
            width: 100vw !important;
            left: calc(-50vw + 50%) !important;
            box-sizing: border-box !important;
            transform: none !important;
        }
    }

    @media (max-width: 767px) {
        .ladi-element.ladi-auto-scroll {
            overflow-x: auto;
            overflow-y: hidden;
            width: 100% !important;
            left: 0 !important;
            -webkit-overflow-scrolling: touch;
        }

        [data-hint]:not([data-timeout-id-copied]):before,
        [data-hint]:not([data-timeout-id-copied]):after {
            display: none !important;
        }

        .ladi-section.ladi-auto-scroll {
            overflow-x: auto;
            overflow-y: hidden;
            -webkit-overflow-scrolling: touch;
        }
    }
</style>
<style id="style_page" type="text/css">
    body {
        direction: ltr;
    }

    @media (min-width: 768px) {
        .ladi-section .ladi-container {
            width: 960px;
        }
    }

    @media (max-width: 767px) {
        .ladi-section .ladi-container {
            width: 420px;
        }
    }

    body {
        font-family: "Open Sans", sans-serif
    }
</style>
<style id="style_element" type="text/css">
    #SECTION6>.ladi-section-background {
        background-size: auto 100%;
        background-origin: content-box;
        background-position: 50% 50%;
        background-repeat: no-repeat;
        background-attachment: scroll;
        filter: contrast(127%) brightness(81%) saturate(116%);
        opacity: 0.96;
    }

    #IMAGE362>.ladi-image {
        filter: contrast(87%) brightness(109%) saturate(107%);
    }

    #IMAGE362:hover>.ladi-image,
    #IMAGE365:hover>.ladi-image,
    #IMAGE366:hover>.ladi-image,
    #IMAGE369:hover>.ladi-image {
        opacity: 1;
    }

    #IMAGE365>.ladi-image>.ladi-image-background,
    #IMAGE366>.ladi-image>.ladi-image-background,
    #IMAGE369>.ladi-image>.ladi-image-background,
    #IMAGE375>.ladi-image>.ladi-image-background,
    #IMAGE376>.ladi-image>.ladi-image-background {
        top: 0px;
        left: 0px;
    }

    #IMAGE365>.ladi-image>.ladi-image-background {
        background-image: url("https://w.ladicdn.com/s700x400/63ea36ac81c3610012d6c96c/btn_quick_play-20230222161149-tert8.png");
    }

    #IMAGE365>.ladi-image {
        filter: contrast(104%) brightness(108%) saturate(110%);
    }

    #IMAGE375>.ladi-image>.ladi-image-background {
        background-image: url("https://w.ladicdn.com/s400x400/63ea36ac81c3610012d6c96c/icon-livechat-20230620064853-y7vmv.png");
    }

    #IMAGE376>.ladi-image>.ladi-image-background {
        background-image: url("https://w.ladicdn.com/s400x400/63ea36ac81c3610012d6c96c/icon-phone-20230620064858-hlk0s.png");
    }

    @media (min-width: 768px) {
        #SECTION6 {
            height: 1079px;
        }

        #SECTION6>.ladi-section-background {
            background-image: url("https://w.ladicdn.com/s1440x1079/63ea36ac81c3610012d6c96c/backgo88nez-20230620064422-qjaes.jpg");
        }

        #IMAGE362 {
            width: 511.299px;
            height: 306.32px;
            top: -34px;
            left: 251.516px;
        }

        #IMAGE362>.ladi-image>.ladi-image-background {
            width: 511.299px;
            height: 227.244px;
            top: 44.2453px;
            left: -5.53065px;
            background-image: url("https://w.ladicdn.com/s850x550/63ea36ac81c3610012d6c96c/go88newz-20230620064436-ut8f0.png");
        }

        #IMAGE365,
        #IMAGE365>.ladi-image>.ladi-image-background {
            width: 360.029px;
            height: 80.831px;
        }

        #IMAGE365 {
            top: 327.32px;
            left: 298.091px;
        }

        #IMAGE366,
        #IMAGE366>.ladi-image>.ladi-image-background {
            width: 372.955px;
            height: 90.8429px;
        }

        #IMAGE366 {
            top: 465.151px;
            left: 295.023px;
        }

        #IMAGE366>.ladi-image>.ladi-image-background {
            background-image: url("https://w.ladicdn.com/s700x400/63ea36ac81c3610012d6c96c/btn-ios-1-20230222161149-7nkio.png");
        }

        #IMAGE369,
        #IMAGE369>.ladi-image>.ladi-image-background {
            width: 379.091px;
            height: 93.231px;
        }

        #IMAGE369 {
            top: 592px;
            left: 295.023px;
        }

        #IMAGE369>.ladi-image>.ladi-image-background {
            background-image: url("https://w.ladicdn.com/s700x400/63ea36ac81c3610012d6c96c/btn-android-1-20230222161149-yrsj1.png");
        }

        #IMAGE375,
        #IMAGE375>.ladi-image>.ladi-image-background,
        #IMAGE376,
        #IMAGE376>.ladi-image>.ladi-image-background {
            width: 78px;
            height: 78px;
        }

        #IMAGE375 {
            top: 63px;
            left: 725.815px;
        }

        #IMAGE376 {
            top: 63px;
            left: 104px;
        }
    }

    @media (max-width: 767px) {
        #SECTION6 {
            height: 1183.43px;
        }

        #SECTION6>.ladi-section-background {
            background-image: url("https://w.ladicdn.com/s768x1183/63ea36ac81c3610012d6c96c/backgo88nez-20230620064422-qjaes.jpg");
        }

        #IMAGE362 {
            width: 417.592px;
            height: 192.904px;
            top: 0px;
            left: 2.254px;
        }

        #IMAGE362>.ladi-image>.ladi-image-background {
            width: 414.098px;
            height: 204.322px;
            top: -3.88008px;
            left: 3.49426px;
            background-image: url("https://w.ladicdn.com/s750x550/63ea36ac81c3610012d6c96c/go88newz-20230620064436-ut8f0.png");
        }

        #IMAGE365,
        #IMAGE365>.ladi-image>.ladi-image-background {
            width: 365.992px;
            height: 82.7407px;
        }

        #IMAGE365 {
            top: 272.423px;
            left: 35.004px;
        }

        #IMAGE366 {
            width: 312.104px;
            height: 70.215px;
            top: 390px;
            left: 53.948px;
        }

        #IMAGE366>.ladi-image>.ladi-image-background {
            width: 312.104px;
            height: 77.215px;
            background-image: url("https://w.ladicdn.com/s650x400/63ea36ac81c3610012d6c96c/btn-ios-1-20230222161149-7nkio.png");
        }

        #IMAGE369,
        #IMAGE369>.ladi-image>.ladi-image-background {
            width: 319.488px;
            height: 76.8791px;
        }

        #IMAGE369 {
            top: 489.259px;
            left: 51.306px;
        }

        #IMAGE369>.ladi-image>.ladi-image-background {
            background-image: url("https://w.ladicdn.com/s650x400/63ea36ac81c3610012d6c96c/btn-android-1-20230222161149-yrsj1.png");
        }

        #IMAGE375,
        #IMAGE375>.ladi-image>.ladi-image-background {
            width: 57.191px;
            height: 57.191px;
        }

        #IMAGE375 {
            top: 48.944px;
            left: 362.809px;
        }

        #IMAGE376,
        #IMAGE376>.ladi-image>.ladi-image-background {
            width: 59.254px;
            height: 59.254px;
        }

        #IMAGE376 {
            top: 39.944px;
            left: 0px;
        }
    }
</style>
<style id="style_lazyload" type="text/css">
    .ladi-overlay,
    .ladi-box,
    .ladi-button-background,
    .ladi-collection-item:before,
    .ladi-countdown-background,
    .ladi-form-item-background,
    .ladi-form-label-container .ladi-form-label-item.image,
    .ladi-frame-background,
    .ladi-gallery-view-item,
    .ladi-gallery-control-item,
    .ladi-headline,
    .ladi-image-background,
    .ladi-image-compare,
    .ladi-list-paragraph ul li:before,
    .ladi-section-background,
    .ladi-survey-option-background,
    .ladi-survey-option-image,
    .ladi-tabs-background,
    .ladi-video-background,
    .ladi-banner,
    .ladi-spin-lucky-screen,
    .ladi-spin-lucky-start {
        background-image: none !important;
    }
</style>
<script>!function (e, t, r, n, c) { if (!e.ztrq) { c = e.ztrq = function () { c.queue ? c.queue.push(arguments) : c.call(c, arguments) }, e._ztrk || (e._ztrk = c), c.queue = []; var u = t.createElement(r); u.async = !0, u.src = n; var a = t.getElementsByTagName(r)[0]; a.parentNode.insertBefore(u, a) } }(window, document, "script", "https://s.zzcdn.me/ztr/ztracker.js?id=7056840457216708608"); window.LadiPageZaloAds = { auto_tracking: true }; ztrq("track", "ViewContent");</script>
</head>

<body>
    <div class="ladi-wraper">
        <div id="SECTION6" class='ladi-section'>
            <div class='ladi-section-background'></div>
            <div class="ladi-container">
                <div id="IMAGE362" class='ladi-element'>
                    <div class='ladi-image ladi-transition'>
                        <div class="ladi-image-background"></div>
                    </div>
                </div><a href="http://play.hit28z.club/" target="_blank" id="IMAGE365" class='ladi-element'>
                    <div class='ladi-image ladi-transition'>
                        <div class="ladi-image-background"></div>
                    </div>
                </a><a href="https://apps.apple.com/app/id6445899462" target="_blank" id="IMAGE366" class='ladi-element'>
                    <div class='ladi-image ladi-transition'>
                        <div class="ladi-image-background"></div>
                    </div>
                </a><a href="https://hit28z.club/assets/download/Hit.apk" target="_blank" id="IMAGE369" class='ladi-element'>
                    <div class='ladi-image ladi-transition'>
                        <div class="ladi-image-background"></div>
                    </div>
                </a>
                <div id="IMAGE375" class='ladi-element'>
                    <div class='ladi-image'>
                        <div class="ladi-image-background"></div>
                    </div>
                </div>
                <div id="IMAGE376" class='ladi-element'>
                    <div class='ladi-image'>
                        <div class="ladi-image-background"></div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="backdrop-popup" class="backdrop-popup"></div>
    <div id="backdrop-dropbox" class="backdrop-dropbox"></div>
    <div id="lightbox-screen" class="lightbox-screen"></div>
    <script id="script_lazyload"
        type="text/javascript">window.lazyload_run = function (dom, is_first, check_dom_rect) { if (check_dom_rect && (document.body.clientWidth <= 0 || document.body.clientheight <= 0)) { return setTimeout(function () { window.lazyload_run(dom, is_first, check_dom_rect); }, 1); } var style_lazyload = document.getElementById('style_lazyload'); var list_element_lazyload = dom.querySelectorAll('.ladi-overlay, .ladi-box, .ladi-button-background, .ladi-collection-item, .ladi-countdown-background, .ladi-form-item-background, .ladi-form-label-container .ladi-form-label-item.image, .ladi-frame-background, .ladi-gallery-view-item, .ladi-gallery-control-item, .ladi-headline, .ladi-image-background, .ladi-image-compare, .ladi-list-paragraph ul li, .ladi-section-background, .ladi-survey-option-background, .ladi-survey-option-image, .ladi-tabs-background, .ladi-video-background, .ladi-banner, .ladi-spin-lucky-screen, .ladi-spin-lucky-start'); var docEventScroll = window; for (var i = 0; i < list_element_lazyload.length; i++) { var rect = list_element_lazyload[i].getBoundingClientRect(); if (rect.x == "undefined" || rect.x == undefined || rect.y == "undefined" || rect.y == undefined) { rect.x = rect.left; rect.y = rect.top; } var offset_top = rect.y + window.scrollY; if (offset_top >= window.scrollY + window.innerHeight || window.scrollY >= offset_top + list_element_lazyload[i].offsetHeight) { list_element_lazyload[i].classList.add('ladi-lazyload'); } } if (typeof style_lazyload != "undefined" && style_lazyload != undefined) { style_lazyload.parentElement.removeChild(style_lazyload); } var currentScrollY = window.scrollY; var stopLazyload = function (event) { if (event.type == "scroll" && window.scrollY == currentScrollY) { currentScrollY = -1; return; } docEventScroll.removeEventListener('scroll', stopLazyload); list_element_lazyload = document.getElementsByClassName('ladi-lazyload'); while (list_element_lazyload.length > 0) { list_element_lazyload[0].classList.remove('ladi-lazyload'); } }; if (is_first) { var scrollEventPassive = null; try { var opts = Object.defineProperty({}, 'passive', { get: function () { scrollEventPassive = { passive: true }; } }); window.addEventListener('testPassive', null, opts); window.removeEventListener('testPassive', null, opts); } catch (e) { } docEventScroll.addEventListener('scroll', stopLazyload, scrollEventPassive); } return dom; }; window.lazyload_run(document, true, true);</script>
    <!--[if lt IE 9]><script src="https://w.ladicdn.com/v2/source/html5shiv.min.js?v=1691642835202"></script><script src="https://w.ladicdn.com/v2/source/respond.min.js?v=1691642835202"></script><![endif]-->
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;700&display=swap" rel="stylesheet"
        type="text/css">
    <script src="https://w.ladicdn.com/v2/source/ladipagev3.min.js?v=1691642835202" type="text/javascript"></script>
    <script id="script_event_data"
        type="application/json">{"IMAGE365":{"a":"image","cs":[{"dr":"action","dv":"_blank","dw":"https://play.go88n.city/","a":"link"}]},"IMAGE366":{"a":"image","cs":[{"dr":"action","dv":"_blank","dw":"https://apps.apple.com/app/id1660435149","a":"link"}]},"IMAGE369":{"a":"image","cs":[{"dr":"action","dv":"_blank","dw":"https://go88n.city/assets/download/GO88.apk?v=1","a":"link"}]}}</script>
    <script id="script_ladipage_run"
        type="text/javascript">(function () { var run = function () { if (typeof window.LadiPageScript == "undefined" || typeof window.ladi == "undefined" || window.ladi == undefined) { setTimeout(run, 100); return; } window.LadiPageApp = window.LadiPageApp || new window.LadiPageAppV2(); window.LadiPageScript.runtime.ladipage_id = '64914a7b4a37000012f83c31'; window.LadiPageScript.runtime.publish_platform = 'LADIPAGE'; window.LadiPageScript.runtime.version = '1691642835202'; window.LadiPageScript.runtime.cdn_url = 'https://w.ladicdn.com/v2/source/'; window.LadiPageScript.runtime.DOMAIN_FREE = ["preview.ladipage.me", "ldp.link", "ldp.page"]; window.LadiPageScript.runtime.bodyFontSize = 12; window.LadiPageScript.runtime.store_id = "63ea36ac81c3610012d6c96c"; window.LadiPageScript.runtime.time_zone = 7; window.LadiPageScript.runtime.currency = "USD"; window.LadiPageScript.runtime.convert_replace_str = true; window.LadiPageScript.runtime.desktop_width = 960; window.LadiPageScript.runtime.mobile_width = 420; window.LadiPageScript.runtime.tracking_button_click = true; window.LadiPageScript.runtime.lang = "vi"; window.LadiPageScript.run(true); window.LadiPageScript.runEventScroll(); }; run(); })();</script>
</body>

</html><!--Publish time: Fri, 11 Aug 2023 13:13:41 GMT--><!--LadiPage build time: Thu, 10 Aug 2023 04:47:15 GMT-->

